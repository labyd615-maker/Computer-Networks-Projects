NOTES FOR Future :)

TCP Task 2
Port: 7159 = last three digits of ID1 (159) + 7000.

How to run:
1. Open CMD in this folder.
2. Run: python server.py
3. Open another CMD in this folder.
4. Run: python client.py

Expected result:
The client sends HELLO SERVER, Message 1 to Message 10, and DONE.
The server prints all messages in order and sends ACK1, ACK2, ... after every message.
