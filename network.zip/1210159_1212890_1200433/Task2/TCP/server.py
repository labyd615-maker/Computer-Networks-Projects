from socket import socket, AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR

HOST = "0.0.0.0"
PORT = 7159  # Last 3 digits of ID1 (1210159) + 7000
BUFFER_SIZE = 1024


def main():
    message_count = 0
    buffer = ""

    server_socket = socket(AF_INET, SOCK_STREAM)
    server_socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)

    print(f"TCP server is listening on port {PORT} ...")
    connection_socket, client_address = server_socket.accept()
    print(f"Client connected from IP={client_address[0]}, Port={client_address[1]}")

    try:
        while True:
            data = connection_socket.recv(BUFFER_SIZE)
            if not data:
                print("Client closed the connection.")
                break

            buffer += data.decode(errors="replace")

            while "\n" in buffer:
                message, buffer = buffer.split("\n", 1)
                message = message.strip()
                if not message:
                    continue

                message_count += 1
                print(f"Received #{message_count}: {message}")

                ack = f"ACK{message_count}\n"
                connection_socket.sendall(ack.encode())
                print(f"Sent: ACK{message_count}")

                if message == "DONE":
                    print(f"DONE received. Total messages received = {message_count}")
                    return
    finally:
        connection_socket.close()
        server_socket.close()
        print("TCP server closed.")


if __name__ == "__main__":
    main()
