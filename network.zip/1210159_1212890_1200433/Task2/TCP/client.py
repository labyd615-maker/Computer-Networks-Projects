from socket import socket, AF_INET, SOCK_STREAM

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 7159  # Last 3 digits of ID1 (1210159) + 7000
BUFFER_SIZE = 1024


def receive_line(client_socket):
    buffer = ""
    while "\n" not in buffer:
        data = client_socket.recv(BUFFER_SIZE)
        if not data:
            return buffer.strip()
        buffer += data.decode(errors="replace")
    return buffer.split("\n", 1)[0].strip()


def main():
    messages = ["HELLO SERVER"]
    messages.extend([f"Message {i}" for i in range(1, 11)])
    messages.append("DONE")

    client_socket = socket(AF_INET, SOCK_STREAM)
    print(f"Connecting to TCP server {SERVER_HOST}:{SERVER_PORT} ...")
    client_socket.connect((SERVER_HOST, SERVER_PORT))

    try:
        for message in messages:
            print(f"Sending: {message}")
            client_socket.sendall((message + "\n").encode())
            ack = receive_line(client_socket)
            print(f"Received from server: {ack}")
    finally:
        client_socket.close()
        print("TCP client closed.")


if __name__ == "__main__":
    main()
