NOTES FOR Future :)

UDP Task 2
Port: 7160 = last three digits of ID1 (159) + 7001.

How to run:
1. Open CMD in this folder.
2. Run: python server.py
3. Open another CMD in this folder.
4. Run: python client.py

Expected result:
The client sends Packet-1 to Packet-200.
The server counts received packets, detects missing packets, and detects out-of-order packets.
On localhost, missing/out-of-order packets are usually 0 because the local machine is very reliable.
