from socket import socket, AF_INET, SOCK_DGRAM, SOL_SOCKET, SO_REUSEADDR

HOST = "0.0.0.0"
PORT = 7160  # Last 3 digits of ID1 (1210159) + 7001
BUFFER_SIZE = 1024
EXPECTED_PACKETS = 200
TIMEOUT_SECONDS = 5


def extract_packet_number(packet_text):
    # Expected format: Packet-1, Packet-2, ..., Packet-200
    try:
        prefix, number = packet_text.strip().split("-")
        if prefix != "Packet":
            return None
        return int(number)
    except Exception:
        return None


def main():
    received_numbers = []
    received_set = set()
    out_of_order_count = 0
    last_number = 0

    server_socket = socket(AF_INET, SOCK_DGRAM)
    server_socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.settimeout(TIMEOUT_SECONDS)

    print(f"UDP server is listening on port {PORT} ...")
    print(f"Waiting for up to {EXPECTED_PACKETS} packets. Timeout = {TIMEOUT_SECONDS} seconds after last packet.")

    while len(received_numbers) < EXPECTED_PACKETS:
        try:
            data, client_address = server_socket.recvfrom(BUFFER_SIZE)
        except TimeoutError:
            print("Timeout reached. No more packets received.")
            break

        text = data.decode(errors="replace").strip()
        packet_number = extract_packet_number(text)
        print(f"Received from IP={client_address[0]}, Port={client_address[1]}: {text}")

        if packet_number is None:
            continue

        received_numbers.append(packet_number)
        received_set.add(packet_number)

        if packet_number < last_number:
            out_of_order_count += 1
        last_number = packet_number

    missing_packets = [i for i in range(1, EXPECTED_PACKETS + 1) if i not in received_set]

    print("\n========== UDP Analysis ==========")
    print(f"Total packets expected: {EXPECTED_PACKETS}")
    print(f"Total packets received: {len(received_numbers)}")
    print(f"Number of missing packets: {len(missing_packets)}")
    print(f"Missing packets: {missing_packets if missing_packets else 'None'}")
    print(f"Number of out-of-order packets: {out_of_order_count}")
    print("==================================")

    server_socket.close()


if __name__ == "__main__":
    main()
