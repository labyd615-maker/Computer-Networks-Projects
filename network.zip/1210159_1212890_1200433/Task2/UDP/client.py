from socket import socket, AF_INET, SOCK_DGRAM
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 7160  # Last 3 digits of ID1 (1210159) + 7001
TOTAL_PACKETS = 200
DELAY_SECONDS = 0.005


def main():
    client_socket = socket(AF_INET, SOCK_DGRAM)
    print(f"Sending {TOTAL_PACKETS} UDP packets to {SERVER_HOST}:{SERVER_PORT} ...")

    try:
        for i in range(1, TOTAL_PACKETS + 1):
            message = f"Packet-{i}"
            client_socket.sendto(message.encode(), (SERVER_HOST, SERVER_PORT))
            print(f"Sent: {message}")
            time.sleep(DELAY_SECONDS)
    finally:
        client_socket.close()
        print("UDP client closed.")


if __name__ == "__main__":
    main()
