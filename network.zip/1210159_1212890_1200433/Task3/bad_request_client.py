from socket import socket, AF_INET, SOCK_STREAM

HOST = "127.0.0.1"
PORT = 6159

bad_request = "BAD REQUEST WITHOUT HTTP FORMAT\r\n\r\n"

client_socket = socket(AF_INET, SOCK_STREAM)
client_socket.connect((HOST, PORT))
client_socket.sendall(bad_request.encode())
response = client_socket.recv(4096).decode(errors="replace")
print(response)
client_socket.close()
