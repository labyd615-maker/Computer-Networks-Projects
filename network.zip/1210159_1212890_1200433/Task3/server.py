from socket import socket, AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR
from pathlib import Path
from urllib.parse import unquote
import mimetypes

HOST = "0.0.0.0"
PORT = 6159  # Last 3 digits of ID1 (1210159) + 6000
BUFFER_SIZE = 4096

BASE_DIR = Path(__file__).parent.resolve()
HTML_DIR = BASE_DIR / "html"
CSS_DIR = BASE_DIR / "css"
IMGS_DIR = BASE_DIR / "imgs"
SHARED_DIR = BASE_DIR / "shared"

TOTAL_REQUESTS = 0
SUCCESSFUL_DOWNLOADS = 0
FAILED_REQUESTS = 0


def build_response(status_code, reason, body=b"", content_type="text/html; charset=utf-8"):
    headers = [
        f"HTTP/1.1 {status_code} {reason}",
        f"Content-Type: {content_type}",
        f"Content-Length: {len(body)}",
        "Connection: close",
        "",
        ""
    ]
    return "\r\n".join(headers).encode() + body


def safe_path(root, requested_name):
    requested_name = unquote(requested_name).lstrip("/")
    candidate = (root / requested_name).resolve()
    if root.resolve() not in candidate.parents and candidate != root.resolve():
        return None
    return candidate


def generate_file_links():
    links = []
    for file_path in sorted(SHARED_DIR.iterdir()):
        if file_path.is_file():
            links.append(f'<a href="/shared/{file_path.name}" download>{file_path.name}</a><br>')
    return "\n".join(links)


def load_home_page(language="en"):
    page_name = "home_ar.html" if language == "ar" else "home_en.html"
    html = (HTML_DIR / page_name).read_text(encoding="utf-8")
    return html.replace("<!-- FILE_LIST -->", generate_file_links()).encode("utf-8")


def handle_request(request_text):
    global SUCCESSFUL_DOWNLOADS, FAILED_REQUESTS

    lines = request_text.splitlines()
    if not lines:
        FAILED_REQUESTS += 1
        body = b"<html><body><h1 class='error'>400 Bad Request</h1></body></html>"
        return build_response(400, "Bad Request", body), "UNKNOWN", 400

    request_line = lines[0]
    parts = request_line.split()

    if len(parts) != 3 or parts[0] != "GET" or not parts[2].startswith("HTTP/"):
        FAILED_REQUESTS += 1
        body = b"<html><body><h1>400 Bad Request</h1><p>Malformed HTTP request.</p></body></html>"
        return build_response(400, "Bad Request", body), request_line, 400

    resource = parts[1]

    if resource in ["/", "/index.html", "/home_en.html", "/en"]:
        body = load_home_page("en")
        return build_response(200, "OK", body), resource, 200

    if resource in ["/ar", "/home_ar.html"]:
        body = load_home_page("ar")
        return build_response(200, "OK", body), resource, 200

    if resource.startswith("/css/"):
        file_path = safe_path(CSS_DIR, resource.replace("/css/", "", 1))
    elif resource.startswith("/imgs/"):
        file_path = safe_path(IMGS_DIR, resource.replace("/imgs/", "", 1))
    elif resource.startswith("/shared/"):
        file_path = safe_path(SHARED_DIR, resource.replace("/shared/", "", 1))
    else:
        file_path = safe_path(SHARED_DIR, resource)

    if file_path is not None and file_path.exists() and file_path.is_file():
        content_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        body = file_path.read_bytes()
        SUCCESSFUL_DOWNLOADS += 1
        return build_response(200, "OK", body, content_type), resource, 200

    FAILED_REQUESTS += 1
    body = b"<html><body><h1>404 Not Found</h1><p>Requested file not found</p></body></html>"
    return build_response(404, "Not Found", body), resource, 404


def main():
    global TOTAL_REQUESTS

    server_socket = socket(AF_INET, SOCK_STREAM)
    server_socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(5)

    print(f"HTTP file-sharing server is running on http://localhost:{PORT}/")
    print("Press Ctrl+C to stop the server.")

    try:
        while True:
            connection_socket, client_address = server_socket.accept()
            TOTAL_REQUESTS += 1
            request_bytes = connection_socket.recv(BUFFER_SIZE)
            request_text = request_bytes.decode(errors="replace")

            response, requested_resource, status = handle_request(request_text)
            connection_socket.sendall(response)
            connection_socket.close()

            print("\n========== Request Log ==========")
            print(f"Client IP and Port: {client_address[0]}:{client_address[1]}")
            print(f"Requested resource: {requested_resource}")
            print(f"Response status: {status}")
            print(f"Total number of requests: {TOTAL_REQUESTS}")
            print(f"Successful downloads: {SUCCESSFUL_DOWNLOADS}")
            print(f"Failed requests: {FAILED_REQUESTS}")
            print("=================================")
    except KeyboardInterrupt:
        print("\nServer stopped by user.")
    finally:
        server_socket.close()


if __name__ == "__main__":
    main()
