This is a sample text file served by the ENCS3320 file sharing server.
