INFO FOR FUTURE :)

Task 3 File-Sharing Web Server
Port: 6159 = last three digits of ID1 (159) + 6000.

How to run:
1. Open CMD in Task3 folder.
2. Run: python server.py
3. Open a browser and test:
   http://localhost:6159/
   http://localhost:6159/en
   http://localhost:6159/ar
   http://localhost:6159/shared/readme.txt
   http://localhost:6159/shared/about.html
   http://localhost:6159/shared/students.txt
   http://localhost:6159/notfound1.txt
   http://localhost:6159/notfound2.html
4. For 400 Bad Request test, keep server running, open another CMD in Task3, then run:
   python bad_request_client.py

